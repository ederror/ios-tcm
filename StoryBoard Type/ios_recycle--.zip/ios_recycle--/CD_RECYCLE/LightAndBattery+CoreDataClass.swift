//
//  LightAndBattery+CoreDataClass.swift
//  CD_RECYCLE
//
//  Created by 백인찬 on 2021/05/06.
//
//

import Foundation
import CoreData

@objc(LightAndBattery)
public class LightAndBattery: NSManagedObject {

}
