<!--
## 0.0.0

API Changes:

Bugfixes:

Other:
-->


## 0.6.0

API Changes:

- Rename `View` to `CSVView` to avoid SwiftUI namespace conflicts (#93) - @campionfellin

Other:

- Bump iOS Deployment target to 9.0, Xcode 12 recommended changes. (#91) - @DenTelezhkin
