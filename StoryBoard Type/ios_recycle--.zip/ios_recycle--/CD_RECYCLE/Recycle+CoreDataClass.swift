//
//  Recycle+CoreDataClass.swift
//  CD_RECYCLE
//
//  Created by 백인찬 on 2021/05/06.
//
//

import Foundation
import CoreData

@objc(Recycle)
public class Recycle: NSManagedObject {

}
